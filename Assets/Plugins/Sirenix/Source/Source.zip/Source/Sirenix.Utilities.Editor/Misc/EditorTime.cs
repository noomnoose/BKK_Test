#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="EditorTime.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.Utilities.Editor
{
    using System.Collections.Generic;
    using System.Diagnostics;
    using UnityEditor;
    using UnityEngine;
    using Utilities;

    /// <summary>
    /// A utility class for getting delta time for the GUI editor.
    /// </summary>
    [InitializeOnLoad]
    public class EditorTimeHelper
    {
        private static readonly List<int> windowTimeHelpersToRemoveBuffer = new List<int>();
        private static readonly Dictionary<int, EditorTimeHelper> windowTimeHelpers = new Dictionary<int, EditorTimeHelper>();

        /// <summary>
        /// Gets an EditorTimeHelper instance for the current drawing window.
        /// </summary>
        public static EditorTimeHelper Time
        {
            get
            {
                EditorTimeHelper t;
                if (windowTimeHelpers.TryGetValue(GUIHelper.CurrentWindowInstanceID, out t) == false)
                {
                    t = windowTimeHelpers[GUIHelper.CurrentWindowInstanceID] = new EditorTimeHelper();
                }
                return t;
            }
        }

        internal static void RemoveOldWindowTimeHelper()
        {
            foreach (var w in windowTimeHelpers.GFIterator())
            {
                if (EditorUtility.InstanceIDToObject(w.Key) == null)
                {
                    windowTimeHelpersToRemoveBuffer.Add(w.Key);
                }
            }

            for (int i = 0; i < windowTimeHelpersToRemoveBuffer.Count; i++)
            {
                windowTimeHelpersToRemoveBuffer.Remove(windowTimeHelpersToRemoveBuffer[i]);
            }

            windowTimeHelpersToRemoveBuffer.Clear();
        }

        private GUIFrameCounter guiState = new GUIFrameCounter();
        private float[] averageDeltaTimes;
        private int deltaTimeIndex = 0;
        private const float DELTA_TIME_THRESHOLD = 0.2f;
        private readonly Stopwatch stopwatch;
        private float deltaTime;
        private long prevMillisecondsElapsed;
        private float newDeltaTime;
        private uint averageDeltaTimeIndex = 0;
        private float averageDeltaTime;

        /// <summary>
        /// Initializes a new instance of the <see cref="EditorTimeHelper"/> class.
        /// </summary>
        public EditorTimeHelper()
        {
            this.stopwatch = new Stopwatch();
            this.stopwatch.Start();
            this.averageDeltaTimes = new float[20];
            this.averageDeltaTimes.Populate(0.1f);
        }

        /// <summary>
        /// Gets the delta time.
        /// </summary>
        public float DeltaTime
        {
            get { return this.deltaTime; }
        }

        /// <summary>
        /// Updates the delta time.
        /// </summary>
        public void Update()
        {
            // We need some data to start with, otherwise things won't animate smoothly in the beginning.
            if (this.deltaTimeIndex != this.averageDeltaTimes.Length)
            {
                GUIHelper.RequestRepaint();
            }

            if (this.guiState.Update().IsNewFrame)
            {
                this.newDeltaTime = (this.stopwatch.ElapsedMilliseconds - this.prevMillisecondsElapsed) / 1000f;
                this.prevMillisecondsElapsed = this.stopwatch.ElapsedMilliseconds;

                unchecked
                {
                    var delta = Mathf.Min(this.newDeltaTime, DELTA_TIME_THRESHOLD);

                    this.averageDeltaTimes[this.averageDeltaTimeIndex++ % this.averageDeltaTimes.Length] = delta;

                    if (this.deltaTimeIndex != this.averageDeltaTimes.Length)
                    {
                        this.deltaTimeIndex++;
                    }

                    this.averageDeltaTime = 0f;
                    for (int i = 0; i < this.averageDeltaTimes.Length; i++)
                    {
                        this.averageDeltaTime += this.averageDeltaTimes[i];
                    }
                    this.averageDeltaTime /= this.averageDeltaTimes.Length;
                }
            }

            if (Event.current.type == EventType.Layout)
            {
                this.deltaTime = Mathf.Min(this.newDeltaTime, this.averageDeltaTime);
            }
        }
    }
}
#endif