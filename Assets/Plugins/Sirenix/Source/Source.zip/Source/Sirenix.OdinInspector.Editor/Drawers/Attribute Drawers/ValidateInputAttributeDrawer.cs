#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="ValidateInputAttributeDrawer.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using System;
    using System.Reflection;
    using Utilities.Editor;
    using UnityEngine;
    using Utilities;

    /// <summary>
    /// Draws properties marked with <see cref="ValidateInputAttribute"/>.
    /// </summary>
    /// <seealso cref="ValidateInputAttribute"/>
    [OdinDrawer]
    [DrawerPriority(0, 10000, 0)]
    public sealed class ValidateInputAttributeDrawer<T> : OdinAttributeDrawer<ValidateInputAttribute, T>
    {
        private class ValidateContext
        {
            public string ErrorMessage;
            public Func<object, T, bool> InstanceValidationMethodCaller;
            public Func<T, bool> StaticValidationMethodCaller;
			public bool HasError;
			public StringMemberHelper MessageHelper;
		}

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(IPropertyValueEntry<T> entry, ValidateInputAttribute attribute, GUIContent label)
        {
            var context = entry.Property.Context.Get(this, "ValidateInputAttributeDrawer", (ValidateContext)null);

            if (context.Value == null)
            {
                context.Value = new ValidateContext();
                MethodInfo methodInfo = entry.ParentType.FindMember()
                    .IsMethod()
                    .HasReturnType<bool>()
                    .HasParameters(entry.BaseValueType)
                    .IsNamed(attribute.MemberName)
                    .GetMember<MethodInfo>(out context.Value.ErrorMessage);

                if (context.Value.ErrorMessage == null)
                {
                    if (methodInfo.IsStatic())
                    {
                        context.Value.StaticValidationMethodCaller = (Func<T, bool>)Delegate.CreateDelegate(typeof(Func<T, bool>), methodInfo);
                    }
                    else
                    {
                        context.Value.InstanceValidationMethodCaller = EmitUtilities.CreateWeakInstanceMethodCaller<bool, T>(methodInfo);
                    }

                    RunValidation(entry, attribute, context);
                }

				if(attribute.Message != null)
				{
					context.Value.MessageHelper = new StringMemberHelper(entry.ParentType, attribute.Message);
					context.Value.ErrorMessage = context.Value.ErrorMessage ?? context.Value.MessageHelper.ErrorMessage;
				}
            }

            if (context.Value.ErrorMessage != null)
            {
                SirenixEditorGUI.ErrorMessageBox(context.Value.ErrorMessage);
            }

            object key = UniqueDrawerKey.Create(entry.Property, this);
            SirenixEditorGUI.BeginShakeableGroup(key);
            if (context.Value.HasError)
            {
                if (attribute.MessageType == InfoMessageType.Error)
                {
                    SirenixEditorGUI.ErrorMessageBox(context.Value.MessageHelper.GetString(entry));
                }
                else if (attribute.MessageType == InfoMessageType.Warning)
                {
                    SirenixEditorGUI.WarningMessageBox(context.Value.MessageHelper.GetString(entry));
                }
                else if (attribute.MessageType == InfoMessageType.Info)
                {
                    SirenixEditorGUI.InfoMessageBox(context.Value.MessageHelper.GetString(entry));
                }
            }

            GUIUtility.GetControlID(12938712, FocusType.Passive);
            this.CallNextDrawer(entry.Property, label);
            SirenixEditorGUI.EndShakeableGroup(key);

            if (entry.Values.AreDirty)
            {
                if (!RunValidation(entry, attribute, context))
                {
                    SirenixEditorGUI.StartShakingGroup(key);
                }
            }
        }

        private static bool RunValidation(IPropertyValueEntry<T> entry, ValidateInputAttribute attribute, PropertyContext<ValidateContext> context)
        {
            bool hasError = true;

            for (int i = 0; i < entry.Property.ParentValues.Count; i++)
            {
                try
                {
                    if (context.Value.StaticValidationMethodCaller != null)
                    {
                        hasError = context.Value.StaticValidationMethodCaller(entry.Values[i]) == false;
                    }
                    else
                    {
                        hasError = context.Value.InstanceValidationMethodCaller(entry.Property.ParentValues[i], entry.Values[i]) == false;
                    }
                }
                catch (System.Exception ex)
                {
                    Debug.LogException(ex);
                }

                if (hasError)
                {
                    if (attribute.RejectInvalidInput)
                    {
                        entry.Values.RevertUnappliedValues();
                    }
                }

				context.Value.HasError = hasError;
            }

            return !hasError;
        }
    }
}
#endif