#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="GeneralDrawerConfig.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector.Editor
{
	using Sirenix.Utilities;
	using Sirenix.Utilities.Editor;
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using UnityEditor;
	using UnityEngine;

	/// <summary>
	/// <para>Contains general configuration for all Odin drawers.</para>
	/// <para>
	/// You can modify the configuration in the Odin Preferences window found in 'Window -> Odin Inspector -> Preferences -> Drawers -> General',
	/// or by locating the configuration file stored as a serialized object in the Sirenix folder under 'Odin Inspector/Config/Editor/GeneralDrawerConfig'.
	/// </para>
	/// </summary>
	[InitializeOnLoad]
	[SirenixEditorConfig("Odin Inspector/Drawers/General")]
	public class GeneralDrawerConfig : GlobalConfig<GeneralDrawerConfig>
    {
        [InitializeOnLoadMethod]
        private static void LoadEditorPrefs()
        {
			showMonoScriptInEditor = EditorPrefs.GetBool("GeneralDrawerConfig.ShowMonoScriptInEditor", true);
			hideFoldoutWhileEmpty = EditorPrefs.GetBool("GeneralDrawerConfig.HideFoldoutWhileEmpty", true);
			openListsByDefault = EditorPrefs.GetBool("GeneralDrawerConfig.OpenListsByDefault", true);
			showItemCount = EditorPrefs.GetBool("GeneralDrawerConfig.ShowItemCount", true);
			numberOfItemsPrPage = EditorPrefs.GetInt("GeneralDrawerConfig.NumberOfItemsPrPage", 15);
			hidePagingWhileCollapsed = EditorPrefs.GetBool("GeneralDrawerConfig.HidePagingWhileCollapsed", true);
			hidePagingWhileOnlyOnePage = EditorPrefs.GetBool("GeneralDrawerConfig.HidePagingWhileOnlyOnePage", true);
			showExpandButton = EditorPrefs.GetBool("GeneralDrawerConfig.ShowExpandButton", true);
		}

		/// <summary>
		/// Specify weather or not the script selector above components should be drawn.
		/// </summary>
		[TitleGroup("General", indent: false)]
		[ShowInInspector]
		[PropertyTooltip("Specify weather or not the script selector above components should be drawn")]
		public bool ShowMonoScriptInEditor
		{
			get { return showMonoScriptInEditor; }
			set
			{
				showMonoScriptInEditor = value;
				EditorPrefs.SetBool("GeneralDrawerConfig.ShowMonoScriptInEditor", value);
			}
		}

		private static bool showMonoScriptInEditor;

		/// <summary>
		/// If set to true, most foldouts throughout the inspector will be expanded by default.
		/// </summary>
		[TitleGroup("Foldout", indent: false)]
		[ShowInInspector]
		[PropertyTooltip("If set to true, most foldouts throughout the inspector will be expanded by default.")]
		public bool ExpandFoldoutByDefault
		{
			get { return EditorPrefs.GetBool("SirenixEditorGUI.ExpandFoldoutByDefault", true); }
			set
			{
				SirenixEditorGUI.ExpandFoldoutByDefault = value;
				EditorPrefs.SetBool("SirenixEditorGUI.ExpandFoldoutByDefault", value);
			}
		}

		/// <summary>
		/// Specify the animation speed for most foldouts throughout the inspector.
		/// </summary>
		[TitleGroup("Animations", indent: false)]
		[ShowInInspector]
		[PropertyRange(0.001f, 4f)]
		[PropertyTooltip("Specify the animation speed for most foldouts throughout the inspector.")]
		public float GUIFoldoutAnimationDuration
		{
			get { return EditorPrefs.GetFloat("SirenixEditorGUI.DefaultFadeGroupDuration", 0.2f); }
			set
			{
				SirenixEditorGUI.DefaultFadeGroupDuration = value;
				EditorPrefs.SetFloat("SirenixEditorGUI.DefaultFadeGroupDuration", value);
			}
		}

		/// <summary>
		/// Specify the animation speed for <see cref="Sirenix.OdinInspector.TabGroupAttribute"/>
		/// </summary>
		[TitleGroup("Animations")]
		[PropertyRange(0.001f, 4f)]
		public float TabPageSlideAnimationDuration
		{
			get { return EditorPrefs.GetFloat("SirenixEditorGUI.TabPageSlideAnimationDuration", 0.2f); }
			set
			{
				SirenixEditorGUI.TabPageSlideAnimationDuration = value;
				EditorPrefs.SetFloat("SirenixEditorGUI.TabPageSlideAnimationDuration", value);
			}
		}

		/// <summary>
		/// Specify the shaking duration for most shaking animations throughout the inspector.
		/// </summary>
		[TitleGroup("Animations")]
		[PropertyTooltip("Specify the shaking duration for most shaking animations throughout the inspector.")]
		[PropertyRange(0f, 4f)]
		public float ShakingAnimationDuration
		{
			get { return EditorPrefs.GetFloat("SirenixEditorGUI.ShakingAnimationDuration", 0.5f); }
			set
			{
				SirenixEditorGUI.ShakingAnimationDuration = value;
				EditorPrefs.SetFloat("SirenixEditorGUI.ShakingAnimationDuration", value);
			}
		}

		/// <summary>
		/// When <c>true</c> the component labels, for vector fields, will be hidden when the field is too narrow.
		/// </summary>
		[TitleGroup("Vectors", indent: false)]
		[ShowInInspector, PropertyTooltip("When on the component labels, for vector fields, will be hidden when the field is too narrow.\nThis allows more space for the actual component fields themselves.")]
		public bool ResponsiveVectorComponentFields
		{
			get
			{
				return EditorPrefs.GetBool("SirenixEditorFields.ResponsiveVectorComponentFields", true);
			}
			set
			{
				SirenixEditorFields.ResponsiveVectorComponentFields = value;
				EditorPrefs.SetBool("SirenixEditorFields.ResponsiveVectorComponentFields", value);
			}
		}

		/// <summary>
		/// Specify how the Quaternion struct should be shown in the inspector.
		/// </summary>
		[TitleGroup("Vectors")]
		[EnumToggleButtons]
		[ShowInInspector, PropertyTooltip("Current mode for how quaternions are edited in the inspector.\n\nEuler: Rotations as yaw, pitch and roll.\n\nAngle axis: Rotations as a axis of rotation, and an angle of rotation around that axis.\n\nRaw: Directly edit the x, y, z and w components of a quaternion.")]
		public QuaternionDrawMode QuaternionDrawMode
		{
			get { return (QuaternionDrawMode)EditorPrefs.GetInt("GeneralDrawerConfig.QuaternionDrawMode", (int)QuaternionDrawMode.Eulers); }
			set { EditorPrefs.SetInt("GeneralDrawerConfig.QuaternionDrawMode", (int)value); }
		}

		/// <summary>
		/// Specify weather or not a list should hide the foldout triangle when the list is empty.
		/// </summary>
		[TitleGroup("Lists", indent: false)]
		[PropertyOrder(1)]
		[PropertyTooltip("Specifies weather or not a list should hide the foldout triangle when the list is empty.")]
		public bool HideFoldoutWhileEmpty
		{
			get { return hideFoldoutWhileEmpty; }
			set
			{
				hideFoldoutWhileEmpty = value;
				EditorPrefs.SetBool("GeneralDrawerConfig.HideFoldoutWhileEmpty", value);
			}
		}
		private static bool hideFoldoutWhileEmpty;

		/// <summary>
		/// Specify weather or not lists should be expanded or collapsed by default.
		/// </summary>
		[TitleGroup("Lists")]
		[PropertyOrder(1)]
		[PropertyTooltip("Specify weather or not lists should be expanded or collapsed by default.")]
		public bool OpenListsByDefault
		{
			get { return openListsByDefault; }
			set
			{
				openListsByDefault = value;
				EditorPrefs.SetBool("GeneralDrawerConfig.OpenListsByDefault", value);
			}
		}
		private static bool openListsByDefault;

		/// <summary>
		/// Specify weather or not lists should show item count.
		/// </summary>
		[TitleGroup("Lists")]
		[PropertyOrder(1)]
		[PropertyTooltip("Specify weather or not lists should show item count.")]
		public bool ShowItemCount
		{
			get { return showItemCount; }
			set
			{
				showItemCount = value;
				EditorPrefs.SetBool("GeneralDrawerConfig.ShowItemCount", value);
			}
		}
		private static bool showItemCount;

		/// <summary>
		/// Specify the number of elements drawn per page.
		/// </summary>
		[TitleGroup("Lists")]
		[PropertyOrder(1)]
		[OnValueChanged("ResizeExampleList"), MaxValue(500), MinValue(2)]
		[PropertyTooltip("Specify the number of elements drawn per page.")]
		public int NumberOfItemsPrPage
		{
			get { return numberOfItemsPrPage; }
			set
			{
				numberOfItemsPrPage = value;
				EditorPrefs.SetInt("GeneralDrawerConfig.NumberOfItemsPrPage", value);
			}
		}
		private static int numberOfItemsPrPage;

		/// <summary>
		/// Specify weather or not lists should hide the paging buttons when the list is collapsed.
		/// </summary>
		[TitleGroup("Lists")]
		[PropertyOrder(1)]
		[PropertyTooltip("Specify weather or not lists should hide the paging buttons when the list is collapsed.")]
		public bool HidePagingWhileCollapsed
		{
			get { return hidePagingWhileCollapsed; }
			set
			{
				hidePagingWhileCollapsed = value;
				EditorPrefs.SetBool("GeneralDrawerConfig.HidePagingWhileCollapsed", value);
			}
		}
		private static bool hidePagingWhileCollapsed;

		/// <summary>
		/// Specify weather or not lists should hide the paging buttons when there is only one page.
		/// </summary>
		[TitleGroup("Lists")]
		[PropertyOrder(1)]
		public bool HidePagingWhileOnlyOnePage
		{
			get { return hidePagingWhileOnlyOnePage; }
			set
			{
				hidePagingWhileOnlyOnePage = value;
				EditorPrefs.SetBool("GeneralDrawerConfig.HidePagingWhileOnlyOnePage", value);
			}
		}
		private static bool hidePagingWhileOnlyOnePage;

		/// <summary>
		/// Specify weather or not to include a button which expands the list, showing all pages at once.
		/// </summary>
		[TitleGroup("Lists")]
		[PropertyOrder(1)]
		[PropertyTooltip("Specify weather or not to include a button which expands the list, showing all pages at once")]
		public bool ShowExpandButton
		{
			get { return showExpandButton; }
			set
			{
				showExpandButton = value;
				EditorPrefs.SetBool("GeneralDrawerConfig.ShowExpandButton", value);
			}
		}
		private static bool showExpandButton;

#pragma warning disable 0414

		[TitleGroup("Lists")]
		[Space(15)]
		[NonSerialized, ShowInInspector, PropertyOrder(2)]
		private List<int> exampleList = new List<int>();

#pragma warning restore 0414

		private void ResizeExampleList()
		{
			this.exampleList = Enumerable.Range(0, Math.Max(10, (int)(this.NumberOfItemsPrPage * Mathf.PI))).ToList();
		}
	}
}
#endif