﻿//-----------------------------------------------------------------------
// <copyright file="DictionaryDrawerSettings.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector
{
    using System;

    /// <summary>
    /// Customize the behavior for dictionaries in the inspector.
    /// </summary>
    public sealed class DictionaryDrawerSettings : Attribute
    {
        /// <summary>
        /// Specify how the dictionary should draw its items.
        /// </summary>
        public DictionaryDisplayOptions DisplayMode;
    }
}